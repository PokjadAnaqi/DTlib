---@diagnostic disable: duplicate-set-field
local resourceName = "ti_fuel"
if GetResourceState(resourceName) == 'missing' then return end
Fuel = Fuel or {}

---@description Returns the name of the active fuel resource.
---@return string
Fuel.GetResourceName = function()
    return resourceName
end

---@description Returns the current fuel level of a vehicle.
---@param vehicle number The vehicle entity handle.
---@return number The vehicle fuel level.
Fuel.GetFuel = function(vehicle)
    if not DoesEntityExist(vehicle) then return 0.0 end
    local level, _ = exports["ti_fuel"]:getFuel(vehicle)
    return level
end

---@description Sets the fuel level of a vehicle.
---@param vehicle number The vehicle entity handle.
---@param fuel number The fuel level to assign.
---@param type? string The fuel type, used only in ti_fuel. (default: RON91)
---@return nil
Fuel.SetFuel = function(vehicle, fuel, type)
    if not DoesEntityExist(vehicle) then return end
    exports['ti_fuel']:setFuel(vehicle, fuel, type or "RON91")
end

return Fuel